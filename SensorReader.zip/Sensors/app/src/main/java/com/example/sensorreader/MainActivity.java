package com.example.sensorreader;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private EditText userIdEditText, serverAddressEditText;
    private List<ParcelableSensor> selectedSensors = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userIdEditText = findViewById(R.id.edit_text_user_id);
        serverAddressEditText = findViewById(R.id.edit_text_server_address);

        Button sensorSelectionButton = findViewById(R.id.button_sensor_selection);
        sensorSelectionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSensorSelectionActivity();
            }
        });

        Button startStopButton = findViewById(R.id.button_start_stop);
        startStopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isRecording) {
                    startRecording();
                } else {
                    stopRecording();
                }
            }
        });
    }

    private static final int SENSOR_SELECTION_REQUEST_CODE = 1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SENSOR_SELECTION_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                selectedSensors.clear();
                selectedSensors.addAll(Objects.requireNonNull(data.getParcelableArrayListExtra(SensorSelectionActivity.EXTRA_SELECTED_SENSORS)));
            }
        }
    }

    private void openSensorSelectionActivity() {
        Intent intent = new Intent(this, SensorSelectionActivity.class);
        startActivityForResult(intent, SENSOR_SELECTION_REQUEST_CODE);
    }

    private boolean isRecording = false;

    private void startRecording() {
        String userId = userIdEditText.getText().toString();
        String serverAddress = serverAddressEditText.getText().toString();
        if (userId.isEmpty() || serverAddress.isEmpty()) {
            Toast.makeText(this, "Please enter User ID and Server Address", Toast.LENGTH_SHORT).show();
            return;
        }

        // Start the SendDataService to send data to server
        Intent intent = new Intent(this, SendDataService.class);
        intent.setAction("START_SENDING");
        intent.putExtra("user_id", userId);
        intent.putExtra("server_address", serverAddress);
        intent.putParcelableArrayListExtra("selected_sensors", new ArrayList<>(selectedSensors));
        startService(intent);

        // Update recording status
        isRecording = true;
        // Update button text
        Button startStopButton = findViewById(R.id.button_start_stop);
        startStopButton.setText("Stop");
    }

    private void stopRecording() {
        // Stop the service to stop sending data
        Intent intent = new Intent(this, SendDataService.class);
        intent.setAction("STOP_SENDING");
        startService(intent);

        // Update recording status
        isRecording = false;
        // Update button text
        Button startStopButton = findViewById(R.id.button_start_stop);
        startStopButton.setText("Start");
    }
}
