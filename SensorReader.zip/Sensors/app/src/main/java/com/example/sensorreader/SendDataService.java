package com.example.sensorreader;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;

public class SendDataService extends Service {

    private static final int SERVER_PORT = 12345;
    private boolean isSending = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("START_SENDING".equals(action)) {
                String userId = intent.getStringExtra("user_id");
                String serverAddress = intent.getStringExtra("server_address");
                List<ParcelableSensor> selectedSensors = intent.getParcelableArrayListExtra("selected_sensors");

                // Show a toast message to indicate that the service is started
                Toast.makeText(this, "Sending data to server started", Toast.LENGTH_SHORT).show();

                // Start sending data to server
                isSending = true;
                new SendDataToServerTask().execute(userId, serverAddress, selectedSensors);
            } else if ("STOP_SENDING".equals(action)) {
                // Show a toast message to indicate that the service is stopped
                Toast.makeText(this, "Sending data to server stopped", Toast.LENGTH_SHORT).show();

                // Stop sending data
                isSending = false;
                stopSelf();
            }
        }

        return START_NOT_STICKY; // Service will not be restarted if it's stopped by the system
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("StaticFieldLeak")
    private class SendDataToServerTask extends AsyncTask<Object, Void, Void> {

        @Override
        protected Void doInBackground(Object... params) {
            if (params.length < 3 || !(params[0] instanceof String) || !(params[1] instanceof String) || !(params[2] instanceof List)) {
                Log.e("SendDataService", "Invalid parameters passed to doInBackground()");
                return null;
            }

            String userId = (String) params[0];
            String serverAddress = (String) params[1];
            List<ParcelableSensor> selectedSensors = (List<ParcelableSensor>) params[2];

            if (!selectedSensors.isEmpty()) {
                try {
                    Socket socket = new Socket(serverAddress, SERVER_PORT);
                    OutputStream outputStream = socket.getOutputStream();
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
                    StringBuilder dataToSend = new StringBuilder();
                    dataToSend.append("User ID: ").append(userId).append("\n");
                    for (ParcelableSensor sensor : selectedSensors) {
                        dataToSend.append("Sensor: ").append(sensor.getName()).append("\n");
                        // Add sensor data as needed
                    }
                    outputStreamWriter.write(dataToSend.toString());
                    outputStreamWriter.flush();
                    outputStreamWriter.close();
                    outputStream.close();
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("SendDataService", "Selected sensors list is empty or null");
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            // If still sending data, restart the task
            if (isSending) {
                new SendDataToServerTask().execute();
            } else {
                // Otherwise, stop the service
                stopSelf();
            }
        }
    }
}
